DROP TABLE Marina;

DROP TABLE MarinaSlip;

DROP TABLE Owner;

DROP TABLE ServiceCategory;

DROP TABLE ServiceRequest;