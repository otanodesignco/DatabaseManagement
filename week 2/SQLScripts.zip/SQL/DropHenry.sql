DROP TABLE Branch;

DROP TABLE Publisher;

DROP TABLE Author;

DROP TABLE Book;

DROP TABLE Wrote;

DROP TABLE Copy;
