DROP TABLE Rep;

DROP TABLE Customer;

DROP TABLE Orders;

DROP TABLE Part;

DROP TABLE OrderLine;
